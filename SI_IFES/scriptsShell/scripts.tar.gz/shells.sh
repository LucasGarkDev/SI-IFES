#!/bin/bash
awk -F: '{print $NF}' /etc/passwd | sort -u
