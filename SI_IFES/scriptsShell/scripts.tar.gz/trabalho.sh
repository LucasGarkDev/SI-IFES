#!/bin/bash

while true; do
  clear
  echo "------------ MENU ------------"
  echo "1. Comparar dois números"
  echo "2. Contagem regressiva"
  echo "3. Remover espaços em texto"
  echo "4. Verificar substring em texto"
  echo "5. Listar usuários do sistema"
  echo "6. Listar shells únicos"
  echo "7. Sair"
  echo "-------------------------------"
  read -p "Escolha uma opção: " choice

  case $choice in
    1) ./relacao.sh ;;
    2) ./zerador.sh ;;
    3) ./juntatudo.sh ;;
    4) ./substring.sh ;;
    5) ./users.sh ;;
    6) ./shells.sh ;;
    7) echo "Saindo..."; exit 0 ;;
    *) echo "Opção inválida. Tente novamente." ;;
  esac

  read -p "Pressione Enter para continuar..."
done
