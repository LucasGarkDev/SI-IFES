#!/bin/bash

while IFS=: read -r username _ _ _ full_name _; do
  echo -e "$username\t$full_name"
done < /etc/passwd

